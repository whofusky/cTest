#ifndef INFRA_VERSION
#define INFRA_VERSION

#define LIB_INFRA_VERSION "[ Infra src ] Version: V20.000.001"

#endif //INFRA_VERSION
